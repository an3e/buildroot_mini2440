/* pci not implemented yet */

extern int cma_pci_not_implemented;
